const request = require('supertest');
const app = require('../app');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const server = require('../server');
const {
  postComment_controller,
  getAllComment_book,
  get_ref_comments,
  like_comment,
  dislike_comment,
} = require('../SQL/SQL-comment-controller');

jest.mock('../SQL/SQL-comment-controller');
jest.mock('../middlewares/authMiddleware', () => (req, res, next) => {
  req.user = { id: 'test-user-id' };
  next();
});

describe('Comment Routes API', () => {
  let token;
  let serverInstance;

  beforeAll(async () => {
    token = jwt.sign({ id: 'test-user-id' }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });
    serverInstance = server;
  });

  afterAll(async () => {
    await mongoose.connection.close();
    if (serverInstance) {
      await new Promise(resolve => serverInstance.close(resolve));
    }
  });

  describe('POST /api/comment', () => {
    it('should create a new comment', async () => {
      postComment_controller.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/comment')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'book-1', text: 'Great book!' });

      expect(res.status).toBe(201);
      expect(res.body.message).toBe('Comment added successfully');
    });

    it('should create a new comment with commentrefid', async () => {
      postComment_controller.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/comment')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'book-1', text: 'Reply to comment', commentrefid: 'comment-1' });

      expect(res.status).toBe(201);
      expect(res.body.message).toBe('Comment added successfully');
    });

    it('should return 400 for missing bookid', async () => {
        const res = await request(app)
          .post('/api/comment')
          .set('Authorization', `Bearer ${token}`)
          .send({ text: 'Great book!' });
    
        expect(res.status).toBe(400);
        expect(res.body.errors).toEqual(expect.arrayContaining([
          { msg: 'bookid is required', location: 'body', path: 'bookid', type: 'field' },
        ]));
      });
    
      it('should return 400 for missing text', async () => {
        const res = await request(app)
          .post('/api/comment')
          .set('Authorization', `Bearer ${token}`)
          .send({ bookid: 'book-1' });
    
        expect(res.status).toBe(400);
        expect(res.body.errors).toEqual(expect.arrayContaining([
          { msg: 'text is required', location: 'body', path: 'text', type: 'field' },
        ]));
      });

    it('should return 500 for server error', async () => {
      postComment_controller.mockResolvedValue(-1);

      const res = await request(app)
        .post('/api/comment')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'book-1', text: 'Great book!' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('GET /api/comment/book/:bookid', () => {
    it('should return all comments for a book', async () => {
      const mockComments = [
        { CommentID: 1, BookID: 'book-1', Text: 'Great book!', UserID: 'test-user-id' },
      ];
      getAllComment_book.mockResolvedValue(mockComments);

      const res = await request(app).get('/api/comment/book/book-1');

      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockComments);
    });

    it('should return 500 for server error', async () => {
      getAllComment_book.mockRejectedValue(new Error('SQL error'));

      const res = await request(app).get('/api/comment/book/book-1');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error');
    });
  });

  describe('GET /api/comment/ref/:commentid', () => {
    it('should return reference comments', async () => {
      const mockRefComments = [
        { CommentID: 2, RefCommentID: 'comment-1', Text: 'Reply to comment' },
      ];
      get_ref_comments.mockResolvedValue(mockRefComments);

      const res = await request(app).get('/api/comment/ref/comment-1');

      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockRefComments);
    });

    it('should return 500 for server error', async () => {
      get_ref_comments.mockResolvedValue(-1);

      const res = await request(app).get('/api/comment/ref/comment-1');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('PUT /api/comment/like', () => {
    it('should like a comment', async () => {
      like_comment.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/comment/like')
        .send({ commentid: 'comment-1' });

      expect(res.status).toBe(200);
      expect(res.text).toBe('Comment liked successfully');
    });

    it('should return 400 for missing commentid', async () => {
      const res = await request(app)
        .put('/api/comment/like')
        .send({});

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('CommentID is required');
    });

    it('should return 500 for server error', async () => {
      like_comment.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/comment/like')
        .send({ commentid: 'comment-1' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('PUT /api/comment/dislike', () => {
    it('should dislike a comment', async () => {
      dislike_comment.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/comment/dislike')
        .send({ commentid: 'comment-1' });

      expect(res.status).toBe(200);
      expect(res.text).toBe('Comment disliked successfully');
    });

    it('should return 400 for missing commentid', async () => {
      const res = await request(app)
        .put('/api/comment/dislike')
        .send({});

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('CommentID is required');
    });

    it('should return 500 for server error', async () => {
      dislike_comment.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/comment/dislike')
        .send({ commentid: 'comment-1' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });
});