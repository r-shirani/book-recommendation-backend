const request = require('supertest');
const app = require('../app');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const server = require('../server');
const { Readable } = require('stream');
const {
  get_all_user_collections,
  post_user_collection,
  get_collection_details,
  deleteCollection,
  deleteCollectionDetails,
  getCollectionImage,
  get_all_collections_SQL,
  saveCollection_SQL,
  deleteCollection_SQL,
  getCollections_user_SQL,
  addCollectionDetail,
} = require('../SQL/SQL-collection-controller');

jest.mock('../SQL/SQL-collection-controller');
jest.mock('axios'); // موک axios برای تست‌های آپلود

describe('Collection Routes API', () => {
  let token;
  let serverInstance;

  beforeAll(async () => {
    token = jwt.sign({ id: 'test-user-id' }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });
    serverInstance = server; // استفاده از سرور موجود

    // موک getCollectionImage
    getCollectionImage.mockImplementation(collectionid => {
      if (collectionid === 'invalid') {
        return Promise.resolve(0);
      }
      const buffer = Buffer.from('fake-image-data');
      const stream = new Readable({
        read() {
          this.push(buffer);
          this.push(null);
        },
      });
      return Promise.resolve({ stream, contentType: 'image/jpeg' });
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
    if (serverInstance) {
      await new Promise(resolve => serverInstance.close(resolve));
    }
  });

  describe('GET /api/collection/user', () => {
    it('should return user collections', async () => {
      const mockCollections = [
        { CollectionID: 1, Title: 'Collection 1', UserName: 'testuser' },
      ];
      get_all_user_collections.mockResolvedValue(mockCollections);

      const res = await request(app)
        .get('/api/collection/user')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockCollections);
    });

    it('should return 500 for server error', async () => {
      get_all_user_collections.mockResolvedValue(-1);

      const res = await request(app)
        .get('/api/collection/user')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('GET /api/collection/all', () => {
    it('should return all public collections', async () => {
      const mockCollections = [
        {
          CollectionID: 1,
          Title: 'Public Collection',
          UserName: 'testuser',
          FullName: 'Test User',
          Discription: 'A test collection',
          IsOwner: 1,
          IsPublic: true,
        },
      ];
      get_all_collections_SQL.mockResolvedValue(mockCollections);

      const res = await request(app).get('/api/collection/all').query({ pagenum: 1, count: 10 });

      expect(res.status).toBe(200);
      expect(res.body).toEqual([
        {
          collectionid: 1,
          title: 'Public Collection',
          username: 'testuser',
          fullname: 'Test User',
          discription: 'A test collection',
        },
      ]);
    });

    it('should return 204 for no collections', async () => {
      get_all_collections_SQL.mockResolvedValue(null);

      const res = await request(app).get('/api/collection/all').query({ pagenum: 1, count: 10 });

      expect(res.status).toBe(204);
      expect(res.text).toBe('');
    });
  });

  describe('GET /api/collection/anotherUser/:userid', () => {
    it('should return collections for another user', async () => {
      const mockCollections = [
        { CollectionID: 1, Title: 'Collection 1', UserName: 'anotheruser' },
      ];
      get_all_user_collections.mockResolvedValue(mockCollections);

      const res = await request(app).get('/api/collection/anotherUser/another-user-id');

      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockCollections);
    });

    it('should return 500 for server error', async () => {
      get_all_user_collections.mockResolvedValue(-1);

      const res = await request(app).get('/api/collection/anotherUser/another-user-id');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('POST /api/collection/user', () => {
    it('should create a new collection', async () => {
      post_user_collection.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/collection/user')
        .set('Authorization', `Bearer ${token}`)
        .send({ ispublic: true, title: 'New Collection' });

      expect(res.status).toBe(201);
      expect(res.text).toBe('collection added sucessfully');
    });

    it('should return 400 for missing title or ispublic', async () => {
      post_user_collection.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/collection/user')
        .set('Authorization', `Bearer ${token}`)
        .send({ ispublic: true });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('title or ispublic is empty');
    });

    it('should return 500 for server error', async () => {
      post_user_collection.mockResolvedValue(-1);

      const res = await request(app)
        .post('/api/collection/user')
        .set('Authorization', `Bearer ${token}`)
        .send({ ispublic: true, title: 'New Collection' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error(SQL)');
    });
  });

  describe('GET /api/collection/details', () => {
    it('should return collection details', async () => {
      const mockDetails = [
        { CollectionID: 1, BookID: 101, Title: 'Book 1' },
      ];
      get_collection_details.mockResolvedValue(mockDetails);

      const res = await request(app).get('/api/collection/details').query({ collectionid: 1 });

      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockDetails);
    });

    it('should return 400 for missing collectionid', async () => {
      const res = await request(app).get('/api/collection/details');

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter collectionid');
    });

    it('should return 404 for no details found', async () => {
      get_collection_details.mockResolvedValue([]);

      const res = await request(app).get('/api/collection/details').query({ collectionid: 1 });

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('no details in this collection');
    });

    it('should return 500 for server error', async () => {
      get_collection_details.mockResolvedValue(-1);

      const res = await request(app).get('/api/collection/details').query({ collectionid: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error');
    });
  });

  describe('POST /api/collection/details', () => {
    it('should add collection details', async () => {
      addCollectionDetail.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/collection/details')
        .send({ collectionid: 1, bookid: 101 });

      expect(res.status).toBe(201);
      expect(res.body).toEqual({ message: 'collection Details updated', bookid: 101 });
    });

    it('should return 400 for missing collectionid or bookid', async () => {
      const res = await request(app)
        .post('/api/collection/details')
        .send({ collectionid: 1 });

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter collectionid or bookid');
    });

    it('should return 500 for server error', async () => {
      addCollectionDetail.mockResolvedValue(-1);

      const res = await request(app)
        .post('/api/collection/details')
        .send({ collectionid: 1, bookid: 101 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('SQL server error');
    });
  });

  describe('GET /api/collection/pic/:collectionid', () => {
    it('should return collection image', async () => {
      const res = await request(app).get('/api/collection/pic/1');

      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toBe('image/jpeg');
    });

    it('should return 404 for image not found', async () => {
      getCollectionImage.mockResolvedValue(0);

      const res = await request(app).get('/api/collection/pic/invalid');

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('image not found');
    });

    it('should return 400 for missing collectionid', async () => {
      const res = await request(app).get('/api/collection/pic/');

      expect(res.status).toBe(404); // Express به‌طور خودکار 404 برمی‌گرداند
    });

    it('should return 500 for server error', async () => {
      getCollectionImage.mockRejectedValue(new Error('Image fetch error'));

      const res = await request(app).get('/api/collection/pic/1');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error - (error in fetching collection image)');
    });
  });

  describe('POST /api/collection/pic/:collectionid', () => {
    it('should upload collection image', async () => {
      const mockResponse = { message: 'Image uploaded successfully' };
      require('axios').post.mockResolvedValue({ data: mockResponse });

      const res = await request(app)
        .post('/api/collection/pic/1')
        .attach('file', Buffer.from('fake-image'), 'image.jpg');

      expect(res.status).toBe(201);
      expect(res.body).toEqual(mockResponse);
    });

    it('should return 400 for missing file or collectionid', async () => {
      const res = await request(app).post('/api/collection/pic/1');

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('file or collectionid missing');
    });

    it('should return 500 for server error', async () => {
      require('axios').post.mockRejectedValue(new Error('Upload failed'));

      const res = await request(app)
        .post('/api/collection/pic/1')
        .attach('file', Buffer.from('fake-image'), 'image.jpg');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('proxy collection upload failed');
    });
  });

  describe('POST /api/collection/upload-collection', () => {
    it('should upload collection with data', async () => {
      const mockResponse = { message: 'Collection uploaded successfully' };
      require('axios').post.mockResolvedValue({ data: mockResponse });

      const res = await request(app)
        .post('/api/collection/upload-collection')
        .field('data', JSON.stringify({ title: 'New Collection' }))
        .attach('file', Buffer.from('fake-image'), 'image.jpg');

      expect(res.status).toBe(201);
      expect(res.body).toEqual(mockResponse);
    });

    it('should upload collection without file', async () => {
      const mockResponse = { message: 'Collection uploaded successfully' };
      require('axios').post.mockResolvedValue({ data: mockResponse });

      const res = await request(app)
        .post('/api/collection/upload-collection')
        .field('data', JSON.stringify({ title: 'New Collection' }));

      expect(res.status).toBe(201);
      expect(res.body).toEqual(mockResponse);
    });

    it('should return 400 for missing data', async () => {
      const res = await request(app).post('/api/collection/upload-collection');

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('file or data missing');
    });

    it('should return 500 for server error', async () => {
      require('axios').post.mockRejectedValue(new Error('Upload failed'));

      const res = await request(app)
        .post('/api/collection/upload-collection')
        .field('data', JSON.stringify({ title: 'New Collection' }));

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('proxy upload failed');
    });
  });

  describe('DELETE /api/collection/delete-collection', () => {
    it('should delete collection', async () => {
      deleteCollection.mockResolvedValue(1);

      const res = await request(app)
        .delete('/api/collection/delete-collection')
        .query({ collectionid: 1 });

      expect(res.status).toBe(200);
      expect(res.text).toBe('collection deleted');
    });

    it('should return 400 for missing collectionid', async () => {
      const res = await request(app).delete('/api/collection/delete-collection');

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter collectionid');
    });

    it('should return 500 for server error', async () => {
      deleteCollection.mockResolvedValue(-1);

      const res = await request(app)
        .delete('/api/collection/delete-collection')
        .query({ collectionid: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('SQL server error');
    });
  });

  describe('DELETE /api/collection/delete-collection-details', () => {
    it('should delete collection details', async () => {
      deleteCollectionDetails.mockResolvedValue(1);

      const res = await request(app)
        .delete('/api/collection/delete-collection-details')
        .query({ collectionid: 1, bookid: 101 });

      expect(res.status).toBe(200);
      expect(res.body).toEqual({ message: 'collection Details deleted', bookid: '101' });
    });

    it('should return 400 for missing collectionid or bookid', async () => {
      const res = await request(app)
        .delete('/api/collection/delete-collection-details')
        .query({ collectionid: 1 });

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter collectionid or bookid');
    });

    it('should return 500 for server error', async () => {
      deleteCollectionDetails.mockResolvedValue(-1);

      const res = await request(app)
        .delete('/api/collection/delete-collection-details')
        .query({ collectionid: 1, bookid: 101 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('SQL server error');
    });
  });

  describe('GET /api/collection/save', () => {
    it('should return saved collections for user', async () => {
      const mockCollections = [
        { CollectionID: 1, Title: 'Saved Collection', IsOwner: 0 },
      ];
      getCollections_user_SQL.mockResolvedValue(mockCollections);

      const res = await request(app)
        .get('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .query({ count: 20, pagenum: 1 });

      expect(res.status).toBe(200);
      expect(res.body).toEqual({
        message: 'Collections retrieved for user: test-user-id',
        data: mockCollections,
        total: 1,
      });
    });

    it('should return 500 for server error', async () => {
      getCollections_user_SQL.mockRejectedValue(new Error('SQL error'));

      const res = await request(app)
        .get('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .query({ count: 20, pagenum: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error ');
    });
  });

  describe('PUT /api/collection/save', () => {
    it('should save a collection', async () => {
      saveCollection_SQL.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('collection saved for user: test-user-id');
    });

    it('should return 400 for invalid input', async () => {
      saveCollection_SQL.mockResolvedValue(0);

      const res = await request(app)
        .put('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('Failed to save collection: Invalid UserID or AccessibilityGroupID for user test-user-id');
    });

    it('should return 500 for server error', async () => {
      saveCollection_SQL.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error while saving collection for user test-user-id');
    });
  });

  describe('DELETE /api/collection/save', () => {
    it('should delete a saved collection', async () => {
      deleteCollection_SQL.mockResolvedValue(1);

      const res = await request(app)
        .delete('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('Collection deleted for user: test-user-id');
    });

    it('should return 404 for no collection found', async () => {
      deleteCollection_SQL.mockResolvedValue(0);

      const res = await request(app)
        .delete('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('No collection found to delete for user: test-user-id with accessibilitygroup: 1');
    });

    it('should return 500 for server error', async () => {
      deleteCollection_SQL.mockResolvedValue(-1);

      const res = await request(app)
        .delete('/api/collection/save')
        .set('Authorization', `Bearer ${token}`)
        .send({ accessibilitygroup: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error while deleting collection for user: test-user-id');
    });
  });
});