// tests/auth.test.js
const request = require('supertest');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const axios = require('axios');
const http = require('http');
const app = require('../app'); // مسیر را بر اساس ساختار پروژه تنظیم کنید
const {
  registerUSer_controller,
  loginUser_controller,
  getUserByID,
  getUserData,
  DeleteUser,
  EmailVerificationPut,
  updatePassword_controller,
  updateProfile_controller,
  updateVerifycode_controller,
  userProfileImage,
  update_MBTI_controller,
  DeleteProfilePic,
  checkUserProfileImageExists,
  get_user_genres_controller,
  update_genres,
} = require('../SQL/SQL-user-controller');
const { sendVerificationCode, sendVerificationCode_password } = require('../Auth/mailer');

jest.mock('../SQL/SQL-user-controller');
jest.mock('../Auth/mailer');
jest.mock('../middlewares/authMiddleware', () => (req, res, next) => {
  req.user = { id: 'test-user-id' };
  next();
});
jest.mock('axios');

describe('Auth Routes API', () => {
  let token;
  let server;

  beforeAll(async () => {
    token = jwt.sign({ id: 'test-user-id' }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });
    server = http.createServer(app).listen(0); // استفاده از پورت تصادفی


    userProfileImage.mockImplementation((userid) => {
        if (userid === 'invalid') {
          return Promise.resolve(0); // در صورت نامعتبر بودن userId
        }
        const buffer = Buffer.from('fake-image-data');
        const stream = new Readable({
          read() {
            this.push(buffer);
            this.push(null);
          },
        });
        return Promise.resolve({ stream, contentType: 'image/jpeg' });
      });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  afterAll(async () => {
    if (server) {
      await new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    }
    // بستن اتصال MongoDB
    await mongoose.connection.close();
    jest.resetAllMocks();
  });

  describe('POST /api/auth/register', () => {
    it('should register a new user successfully', async () => {
        // تنظیم mock برای registerUSer_controller
        registerUSer_controller.mockResolvedValue(1); // 1 نشان‌دهنده ثبت‌نام موفق
        // تنظیم mock برای sendVerificationCode
        sendVerificationCode.mockImplementation((email, code) => Promise.resolve()); // تقلید از رفتار واقعی
      
        const res = await request(app)
          .post('/api/auth/register')
          .send({ name: 'Test User', email: 'test@example.com', password: 'password123' });
      
        expect(res.status).toBe(200);
        expect(res.text).toBe('Verification code sent to email.');
      }, 40000);
  
    it('should return 400 for invalid input', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({ name: '', email: 'invalid-email', password: 'short' });
  
      expect(res.status).toBe(400);
      expect(res.body.errors).toEqual(expect.arrayContaining([
        expect.objectContaining({ msg: expect.any(String), path: 'name' }),
        expect.objectContaining({ msg: expect.any(String), path: 'email' }),
        expect.objectContaining({ msg: expect.any(String), path: 'password' }),
      ]));
    }, 40000);
  
    it('should return 400 if user already exists', async () => {
      registerUSer_controller.mockResolvedValue(0);
  
      const res = await request(app)
        .post('/api/auth/register')
        .send({ name: 'Test User', email: 'test@example.com', password: 'password123' });
  
      expect(res.status).toBe(400);
      expect(res.body.message).toBe('this user has already registered!');
    }, 40000);
  
    it('should return 500 for email sending error', async () => {
      registerUSer_controller.mockResolvedValue({ userId: 'new-user-id' });
      sendVerificationCode.mockRejectedValue(new Error('Email error'));
  
      const res = await request(app)
        .post('/api/auth/register')
        .send({ name: 'Test User', email: 'test@example.com', password: 'password123' });
  
      expect(res.status).toBe(500);
    }, 40000);
  });

  describe('POST /api/auth/login', () => {
    it('should login successfully', async () => {
      loginUser_controller.mockResolvedValue({ userId: 'test-user-id', email: 'test@example.com' });

      const res = await request(app)
        .post('/api/auth/login')
        .send({ email: 'test@example.com', password: 'password123' });

      expect(res.status).toBe(201);
      expect(res.body.message).toBe('Logged in successfully');
      expect(res.body.token).toBeDefined();
      expect(res.body.user).toEqual(expect.objectContaining({
        id: 'test-user-id',
        email: 'test@example.com',
      }));
    }, 40000);

    it('should return 400 for invalid input', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({ email: 'invalid-email', password: '' });

      expect(res.status).toBe(400);
      expect(res.body.errors).toEqual(expect.arrayContaining([
        expect.objectContaining({ msg: expect.any(String), path: 'email' }),
        expect.objectContaining({ msg: expect.any(String), path: 'password' }),
      ]));
    }, 40000);

    it('should return 400 for user not found', async () => {
      loginUser_controller.mockResolvedValue(-1);

      const res = await request(app)
        .post('/api/auth/login')
        .send({ email: 'test@example.com', password: 'password123' });

      expect(res.status).toBe(400);
      expect(res.text).toBe('User not found');
    }, 40000);

    it('should return 400 for unverified email', async () => {
      loginUser_controller.mockResolvedValue(-2);

      const res = await request(app)
        .post('/api/auth/login')
        .send({ email: 'test@example.com', password: 'password123' });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('Please verify your email first!');
    }, 40000);

    it('should return 400 for wrong password', async () => {
      loginUser_controller.mockResolvedValue(-3);

      const res = await request(app)
        .post('/api/auth/login')
        .send({ email: 'test@example.com', password: 'password123' });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('wrong password');
    }, 40000);
  });

  describe('GET /api/auth/profile', () => {
    it('should return user profile', async () => {
      getUserByID.mockResolvedValue([{
        userId: 'test-user-id',
        first_name: 'Test',
        last_name: 'User',
        user_name: 'testuser',
        bio: 'Test bio',
        gender: 'M',
        dateOfBrith: '1990-01-01',
        phone_number: '1234567890',
        email: 'test@example.com',
      }]);

      const res = await request(app)
        .get('/api/auth/profile')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User profile');
      expect(res.body.user).toEqual(expect.objectContaining({
        id: 'test-user-id',
        first_name: 'Test',
        last_name: 'User',
        user_name: 'testuser',
        bio: 'Test bio',
        gender: 'M',
        birthday: '1990-01-01',
        phone_number: '1234567890',
        email: 'test@example.com',
      }));
    }, 40000);

    it('should return 404 for user not found', async () => {
      getUserByID.mockResolvedValue([]);

      const res = await request(app)
        .get('/api/auth/profile')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('User not found');
    }, 40000);
  });

  describe('GET /api/auth/profile-another-user', () => {
    it('should return another user profile', async () => {
      getUserByID.mockResolvedValue([{
        userId: 'another-user-id',
        first_name: 'Another',
        last_name: 'User',
        user_name: 'anotheruser',
        bio: 'Another bio',
        mbti: 'INFJ',
      }]);

      const res = await request(app)
        .get('/api/auth/profile-another-user')
        .query({ userid: 'another-user-id' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('public User info');
      expect(res.body.user).toEqual(expect.objectContaining({
        id: 'another-user-id',
        first_name: 'Another',
        last_name: 'User',
        user_name: 'anotheruser',
        bio: 'Another bio',
        mbti: 'INFJ',
      }));
    }, 40000);

    it('should return 404 for user not found', async () => {
      getUserByID.mockResolvedValue([]);

      const res = await request(app)
        .get('/api/auth/profile-another-user')
        .query({ userid: 'another-user-id' });

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('User not found');
    }, 40000);
  });

  describe('PUT /api/auth/newPassword', () => {
    it('should update password successfully', async () => {
      getUserByID.mockResolvedValue([{ userId: 'test-user-id', passwordHash: await bcrypt.hash('oldPassword', 10) }]);
      updatePassword_controller.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/auth/newPassword')
        .set('Authorization', `Bearer ${token}`)
        .send({ oldPassword: 'oldPassword', newPassword: 'newPassword123' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User password updated successfully');
    }, 40000);

    it('should return 404 for wrong old password', async () => {
      getUserByID.mockResolvedValue([{ userId: 'test-user-id', passwordHash: await bcrypt.hash('oldPassword', 10) }]);

      const res = await request(app)
        .put('/api/auth/newPassword')
        .set('Authorization', `Bearer ${token}`)
        .send({ oldPassword: 'wrongPassword', newPassword: 'newPassword123' });

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('wrong password');
    }, 40000);

    it('should return 500 for server error', async () => {
      getUserByID.mockResolvedValue([{ userId: 'test-user-id', passwordHash: await bcrypt.hash('oldPassword', 10) }]);
      updatePassword_controller.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/auth/newPassword')
        .set('Authorization', `Bearer ${token}`)
        .send({ oldPassword: 'oldPassword', newPassword: 'newPassword123' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('SQL server error');
    }, 40000);
  });

  describe('POST /api/auth/verify-code', () => {
    it('should verify code successfully', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id', verificationCode: 123456 });
      EmailVerificationPut.mockResolvedValue(true);

      const res = await request(app)
        .post('/api/auth/verify-code')
        .send({ email: 'test@example.com', code: '123456' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User verified successfully. You can now log in.');
    }, 40000);

    it('should return 400 for wrong code', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id', verificationCode: 123456 });
      DeleteUser.mockResolvedValue(true);

      const res = await request(app)
        .post('/api/auth/verify-code')
        .send({ email: 'test@example.com', code: 'wrongCode' });

      expect(res.status).toBe(400);
      expect(res.text).toBe('wrong verification code');
    }, 40000);
  });

  describe('POST /api/auth/send-verify-code-pass', () => {
    it('should send verification code for password reset', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id' });
      updateVerifycode_controller.mockResolvedValue(1);
      sendVerificationCode_password.mockResolvedValue(true);

      const res = await request(app)
        .post('/api/auth/send-verify-code-pass')
        .send({ email: 'test@example.com' });

      expect(res.status).toBe(200);
      expect(res.text).toBe('Verification code sent to email.');
    }, 40000);

    it('should return 500 for server error', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id' });
      updateVerifycode_controller.mockResolvedValue(-1);

      const res = await request(app)
        .post('/api/auth/send-verify-code-pass')
        .send({ email: 'test@example.com' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error');
    }, 40000);
  });

  describe('POST /api/auth/verify-code-pass', () => {
    it('should verify password reset code', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id', verificationCode: 123456 });

      const res = await request(app)
        .post('/api/auth/verify-code-pass')
        .send({ email: 'test@example.com', code: '123456' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User verified successfully');
    }, 40000);

    it('should return 400 for missing code', async () => {
      const res = await request(app)
        .post('/api/auth/verify-code-pass')
        .send({ email: 'test@example.com', code: '' });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('code field is empty');
    }, 40000);

    it('should return 400 for wrong code', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id', verificationCode: 123456 });

      const res = await request(app)
        .post('/api/auth/verify-code-pass')
        .send({ email: 'test@example.com', code: 'wrongCode' });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('try again wrong code');
    }, 40000);
  });

  describe('PUT /api/auth/settingNewPassword', () => {
    it('should set new password', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id' });
      updatePassword_controller.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/auth/settingNewPassword')
        .send({ email: 'test@example.com', newpass: 'newPassword123' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User password updated successfully');
    }, 40000);

    it('should return 400 for user not found', async () => {
      getUserData.mockResolvedValue(null);

      const res = await request(app)
        .put('/api/auth/settingNewPassword')
        .send({ email: 'test@example.com', newpass: 'newPassword123' });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('User not found');
    }, 40000);

    it('should return 500 for server error', async () => {
      getUserData.mockResolvedValue({ userId: 'test-user-id' });
      updatePassword_controller.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/auth/settingNewPassword')
        .send({ email: 'test@example.com', newpass: 'newPassword123' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('SQL server error');
    }, 40000);
  });

  describe('PUT /api/auth/updateProfile', () => {
    it('should update user profile', async () => {
      updateProfile_controller.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/auth/updateProfile')
        .set('Authorization', `Bearer ${token}`)
        .send({
          new_firstName: 'New',
          new_lastName: 'User',
          new_userName: 'newuser',
          new_bio: 'New bio',
          new_gender: 'M',
          new_birthday: '1990-01-01',
          new_phoneNumber: '1234567890',
        });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('Profile updated successfully!');
    }, 40000);

    it('should return 400 for invalid gender', async () => {
      const res = await request(app)
        .put('/api/auth/updateProfile')
        .set('Authorization', `Bearer ${token}`)
        .send({
          new_firstName: 'New',
          new_lastName: 'User',
          new_userName: 'newuser',
          new_bio: 'New bio',
          new_gender: 'X',
          new_birthday: '1990-01-01',
          new_phoneNumber: '1234567890',
        });

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('gender must be M or F');
    }, 40000);

    it('should return 500 for server error', async () => {
      updateProfile_controller.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/auth/updateProfile')
        .set('Authorization', `Bearer ${token}`)
        .send({
          new_firstName: 'New',
          new_lastName: 'User',
          new_userName: 'newuser',
          new_bio: 'New bio',
          new_gender: 'M',
          new_birthday: '1990-01-01',
          new_phoneNumber: '1234567890',
        });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Something went wrong, try again later!');
    }, 40000);
  });

  describe('GET /api/auth/genres', () => {
    it('should return user genres', async () => {
      get_user_genres_controller.mockResolvedValue(['genre1', 'genre2']);

      const res = await request(app)
        .get('/api/auth/genres')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
    }, 40000);

    it('should return empty array for no genres', async () => {
      get_user_genres_controller.mockResolvedValue([]);

      const res = await request(app)
        .get('/api/auth/genres')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
    }, 40000);
  });

  describe('PUT /api/auth/genres', () => {
    it('should update user genres', async () => {
      update_genres.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/auth/genres')
        .set('Authorization', `Bearer ${token}`)
        .send({ genres: ['genre1', 'genre2'] });

      expect(res.status).toBe(200);
    }, 40000);

    it('should return 500 for server error', async () => {
      update_genres.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/auth/genres')
        .set('Authorization', `Bearer ${token}`)
        .send({ genres: ['genre1', 'genre2'] });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error');
    }, 40000);
  });

  describe('PUT /api/auth/MBTI-update', () => {
    it('should update MBTI', async () => {
      update_MBTI_controller.mockResolvedValue(1);

      const res = await request(app)
        .put('/api/auth/MBTI-update')
        .set('Authorization', `Bearer ${token}`)
        .send({ new_MBTI: 'INFJ' });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('MBTI updated successfully!');
    }, 40000);

    it('should return 400 for missing MBTI', async () => {
      const res = await request(app)
        .put('/api/auth/MBTI-update')
        .set('Authorization', `Bearer ${token}`)
        .send({});

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('MBTI type is required');
    }, 40000);

    it('should return 500 for server error', async () => {
      update_MBTI_controller.mockResolvedValue(-1);

      const res = await request(app)
        .put('/api/auth/MBTI-update')
        .set('Authorization', `Bearer ${token}`)
        .send({ new_MBTI: 'INFJ' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Something went wrong, try again later!');
    }, 40000);
  });

  describe('GET /api/auth/MBTI', () => {
    it('should return user MBTI', async () => {
      getUserByID.mockResolvedValue([{ userId: 'test-user-id', mbti: 'INFJ' }]);

      const res = await request(app)
        .get('/api/auth/MBTI')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('User MBTI:');
      expect(res.body.user).toEqual({ id: 'test-user-id', MBTI: 'INFJ' });
    }, 40000);

    it('should return 404 for user not found', async () => {
      getUserByID.mockResolvedValue([]);

      const res = await request(app)
        .get('/api/auth/MBTI')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('User not found');
    }, 40000);
  });

  describe('GET /api/auth/profilePic/:userid', () => {
    it('should return user profile image', async () => {
        checkUserProfileImageExists.mockResolvedValue(true);
        // mock تابع userProfileImage با استریم سازگار با supertest
        userProfileImage.mockImplementationOnce((userid) => {
          const buffer = Buffer.from('fake-image-data');
          const stream = require('stream').Readable.from(buffer); // استفاده از Readable.from برای سازگاری
          return Promise.resolve({ stream, contentType: 'image/jpeg' });
        });
      
        const res = await request(app).get('/api/auth/profilePic/test-user-id');
      
        expect(res.status).toBe(200);
        expect(res.header['content-type']).toBe('image/jpeg');
    }, 40000);


    it('should return 204 if image does not exist', async () => {
      checkUserProfileImageExists.mockResolvedValue(false);
  
      const res = await request(app).get('/api/auth/profilePic/test-user-id');
  
      expect(res.status).toBe(204);
    }, 40000);
  
    it('should return 400 for access violation', async () => {
      checkUserProfileImageExists.mockResolvedValue(true);
      // userProfileImage برای userid='invalid' مقدار 0 برمی‌گرداند
      const res = await request(app).get('/api/auth/profilePic/invalid');
  
      expect(res.status).toBe(400);
      expect(res.body.message).toBe('Unable to access profile image for userid: invalid due to access violation');
    }, 40000);
  
    it('should return 500 for server error', async () => {
      checkUserProfileImageExists.mockResolvedValue(true);
      // برای شبیه‌سازی خطای سرور، mock را به صورت دستی تغییر می‌دهیم
      userProfileImage.mockResolvedValueOnce(-1);
  
      const res = await request(app).get('/api/auth/profilePic/test-user-id');
  
      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Server error - (error in fetching user profile image for userid: test-user-id)');
    }, 40000);
  });

  describe('GET /api/auth/profilePicToken', () => {
    it('should return user profile image with token', async () => {
        checkUserProfileImageExists.mockResolvedValue(true);
        // mock تابع userProfileImage با استریم سازگار با supertest
        userProfileImage.mockImplementationOnce((userid) => {
          const buffer = Buffer.from('fake-image-data');
          const stream = require('stream').Readable.from(buffer); // استفاده از Readable.from برای سازگاری
          return Promise.resolve({ stream, contentType: 'image/jpeg' });
        });
      
        const res = await request(app)
          .get('/api/auth/profilePicToken')
          .set('Authorization', `Bearer ${token}`);
      
        expect(res.status).toBe(200);
        expect(res.header['content-type']).toBe('image/jpeg');
      }, 20000);
  
    it('should return 204 if image does not exist', async () => {
      checkUserProfileImageExists.mockResolvedValue(false);
  
      const res = await request(app)
        .get('/api/auth/profilePicToken')
        .set('Authorization', `Bearer ${token}`);
  
      expect(res.status).toBe(204);
    }, 20000);
  
    it('should return 400 for access violation', async () => {
      checkUserProfileImageExists.mockResolvedValue(true);
      // برای شبیه‌سازی خطای دسترسی، باید mock را به صورت دستی تغییر دهیم
      userProfileImage.mockImplementationOnce((userid) => Promise.resolve(0));
  
      const res = await request(app)
        .get('/api/auth/profilePicToken')
        .set('Authorization', `Bearer ${token}`);
  
      expect(res.status).toBe(400);
      expect(res.body.message).toBe('Unable to access profile image for userid: test-user-id due to access violation');
    }, 20000);
  
    it('should return 500 for server error', async () => {
      checkUserProfileImageExists.mockResolvedValue(true);
      // برای شبیه‌سازی خطای سرور، mock را به صورت دستی تغییر می‌دهیم
      userProfileImage.mockResolvedValueOnce(-1);
  
      const res = await request(app)
        .get('/api/auth/profilePicToken')
        .set('Authorization', `Bearer ${token}`);
  
      expect(res.status).toBe(500);
      expect(res.body.message).toBe("Server error - userID: test-user-id");
    }, 20000);
  });

  describe('DELETE /api/auth/profilePicToken', () => {
    it('should delete user profile image', async () => {
      DeleteProfilePic.mockResolvedValue(1);

      const res = await request(app)
        .delete('/api/auth/profilePicToken')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
      expect(res.body.message).toBe('image deleted successfully');
    }, 40000);

    it('should return 400 if image not found', async () => {
      DeleteProfilePic.mockResolvedValue(0);

      const res = await request(app)
        .delete('/api/auth/profilePicToken')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('image not found');
    }, 40000);
  });

  
});