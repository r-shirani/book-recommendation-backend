const request = require('supertest');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const app = require('../app');
const http = require('http');
const axios = require('axios');

// Mock کردن وابستگی‌ها
jest.mock('jsonwebtoken');
jest.mock('axios');
jest.mock('../SQL/SQL-rate-controller', () => ({
  post_rate: jest.fn(),
}));
jest.mock('../middlewares/authMiddleware', () => (req, res, next) => {
  req.user = { id: 'test-user-id' };
  next();
});

const { post_rate } = require('../SQL/SQL-rate-controller');

let server;
let token;

beforeAll(async () => {
  token = jwt.sign({ id: 'test-user-id' }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });
  server = http.createServer(app).listen(0); // استفاده از پورت تصادفی
});

afterAll(async () => {
  if (server) {
    await new Promise((resolve) => {
      server.close(resolve);
    });
  }
  await mongoose.connection.close();
  jest.resetAllMocks();
});

describe('Rate and Profile Pic API', () => {
  // تست‌های مربوط به مسیر /api/rate
  describe('POST /api/rate', () => {
    it('should post a rating successfully', async () => {
      post_rate.mockResolvedValue(1); // 1 نشان‌دهنده موفقیت

      const res = await request(app)
        .post('/api/rate')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'test-book-id', rate: 5 });

      expect(res.status).toBe(200);
      expect(res.text).toBe('Rating updated successfully');
    }, 20000);

    it('should return 400 if bookid or rate is missing', async () => {
      const res = await request(app)
        .post('/api/rate')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'test-book-id' }); // rate غایب است

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('bookid or rate missing');
    }, 20000);

    it('should return 500 for server error', async () => {
      post_rate.mockResolvedValue(0); // 0 نشان‌دهنده خطا

      const res = await request(app)
        .post('/api/rate')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'test-book-id', rate: 5 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Internal Server Error');
    }, 20000);

    it('should return 500 for unexpected error', async () => {
      post_rate.mockRejectedValue(new Error('Database error')); // خطای غیرمنتظره

      const res = await request(app)
        .post('/api/rate')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 'test-book-id', rate: 5 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('Internal Server Error');
    }, 20000);
  });

  // تست‌های مربوط به مسیر /api/profile/pic/upload
  describe('POST /api/profile/pic/upload', () => {
    it('should upload profile picture successfully', async () => {
      // Mock کردن درخواست axios
      axios.post.mockResolvedValue({
        status: 201,
        data: { message: 'Profile picture uploaded successfully' },
      });

      const fileBuffer = Buffer.from('fake-image-data');

      const res = await request(app)
        .post('/api/profile/pic/upload')
        .set('Authorization', `Bearer ${token}`)
        .attach('file', fileBuffer, 'test-image.jpg');

      expect(res.status).toBe(201);
      expect(res.body.message).toBe('Profile picture uploaded successfully');
    }, 20000);

    it('should return 400 if file or userid is missing', async () => {
      const res = await request(app)
        .post('/api/profile/pic/upload')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('file or userid missing');
    }, 20000);

    it('should return 400 for bad request from destination server', async () => {
      // Mock کردن خطای 400 از سرور مقصد
      axios.post.mockRejectedValue({
        response: {
          status: 400,
          data: { message: 'Invalid file type' },
        },
      });

      const fileBuffer = Buffer.from('fake-image-data');

      const res = await request(app)
        .post('/api/profile/pic/upload')
        .set('Authorization', `Bearer ${token}`)
        .attach('file', fileBuffer, 'test-image.jpg');

      expect(res.status).toBe(400);
      expect(res.body.message).toBe('Invalid file type');
    }, 20000);

    it('should return 502 for server error from destination server', async () => {
      // Mock کردن خطای 500 از سرور مقصد
      axios.post.mockRejectedValue({
        response: {
          status: 500,
          data: { message: 'Server error at destination' },
        },
      });

      const fileBuffer = Buffer.from('fake-image-data');

      const res = await request(app)
        .post('/api/profile/pic/upload')
        .set('Authorization', `Bearer ${token}`)
        .attach('file', fileBuffer, 'test-image.jpg');

      expect(res.status).toBe(502);
      expect(res.body.message).toBe('Server error at destination');
    }, 20000);

    it('should return 500 for unexpected error', async () => {
      // Mock کردن خطای غیرمنتظره
      axios.post.mockRejectedValue(new Error('Network error'));

      const fileBuffer = Buffer.from('fake-image-data');

      const res = await request(app)
        .post('/api/profile/pic/upload')
        .set('Authorization', `Bearer ${token}`)
        .attach('file', fileBuffer, 'test-image.jpg');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('proxy upload failed');
    }, 20000);
  });
});