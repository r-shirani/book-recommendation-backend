const request = require('supertest');
const app = require('../app');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const server = require('../server');
const { Readable } = require('stream');
const { searchBook_controller, bookImage, likeBook, deletelike, favorit_books, GetBookByID, likeStatus, MBTIbooks } = require('../SQL/SQL-book-controller');

jest.mock('../SQL/SQL-book-controller');

describe('Book Routes API', () => {
  let token;

  beforeAll(async () => {
    token = jwt.sign({ id: 'test-user-id' }, process.env.JWT_SECRET || 'secret', { expiresIn: '1h' });

    // موک bookImage برای شبیه‌سازی استریم
    bookImage.mockImplementation(() => {
      const buffer = Buffer.from('fake-image-data');
      const stream = new Readable({
        read() {
          this.push(buffer);
          this.push(null);
        },
      });
      return Promise.resolve({ stream, contentType: 'image/jpeg' });
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
    server.close();
  });

  describe('GET /api/book/search', () => {
    it('should return books with images for valid search term', async () => {
      const mockBooks = [
        { bookid: 1, title: 'Book 1', fullauthorname: 'Author 1', imageguid: 'image1.jpg' },
      ];
      searchBook_controller.mockResolvedValue(mockBooks);

      const res = await request(app)
        .get('/api/book/search')
        .send({ pagenum: 1, searchterm: 'test' });

      expect(res.status).toBe(200);
      expect(res.body.bookData).toBeDefined();
      expect(res.body.bookData[0].image).toContain('data:image/jpeg;base64');
    });

    it('should return 500 for server error', async () => {
      searchBook_controller.mockResolvedValue(-1);

      const res = await request(app)
        .get('/api/book/search')
        .send({ pagenum: 1, searchterm: 'test' });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error');
    });
  });

  describe('GET /api/book/searchurl/:searchterm', () => {
    it('should return books for valid search term', async () => {
      const mockBooks = [
        { bookid: 1, title: 'Book 1', fullauthorname: 'Author 1', imageguid: 'image1.jpg' },
      ];
      searchBook_controller.mockResolvedValue(mockBooks);

      const res = await request(app).get('/api/book/searchurl/test');

      expect(res.status).toBe(200);
      expect(res.body.updatedBookData).toBeDefined();
      expect(res.body.updatedBookData[0].imageurl).toContain('http://185.173.104.228:9547/api/v1/images/file/');
    });

    it('should return 400 for missing search term', async () => {
      const res = await request(app).get('/api/book/searchurl/%20');

      expect(res.status).toBe(400);
      expect(res.text).toBe('enter searchterm');
    });

    it('should return 204 for no books found', async () => {
      searchBook_controller.mockResolvedValue(0);

      const res = await request(app).get('/api/book/searchurl/test');

      expect(res.status).toBe(204);
    });
  });

  describe('GET /api/book/image/:bookid', () => {
    it('should return book image for valid bookid', async () => {
      const res = await request(app).get('/api/book/image/1');

      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toBe('image/jpeg');
    });

    it('should return 500 for server error', async () => {
      bookImage.mockRejectedValue(new Error('Image fetch error'));

      const res = await request(app).get('/api/book/image/1');

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error - (error in fetching image)');
    });
  });

  describe('GET /api/book/popularBooks', () => {
    it('should return popular books', async () => {
      const mockBooks = [
        { bookid: 1, title: 'Book 1', fullauthorname: 'Author 1', avgrate: 4.5 },
      ];
      searchBook_controller.mockResolvedValue(mockBooks);

      const res = await request(app)
        .get('/api/book/popularBooks')
        .send({ pagenum: 1 });

      expect(res.status).toBe(200);
      expect(res.body).toEqual([
        { bookid: 1, title: 'Book 1', author: 'Author 1', avgrate: 4.5 },
      ]);
    });

    it('should return 204 for no books found', async () => {
      searchBook_controller.mockResolvedValue(null);

      const res = await request(app)
        .get('/api/book/popularBooks')
        .send({ pagenum: 1 });

      expect(res.status).toBe(204);
    });
  });

  describe('POST /api/book/like', () => {
    it('should like a book successfully', async () => {
      likeBook.mockResolvedValue(1);

      const res = await request(app)
        .post('/api/book/like')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 1 });

      expect(res.status).toBe(200);
      expect(res.text).toBe('liked');
    });

    it('should return 500 for server error', async () => {
      likeBook.mockResolvedValue(0);

      const res = await request(app)
        .post('/api/book/like')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error');
    });
  });

  describe('DELETE /api/book/dislike', () => {
    it('should dislike a book successfully', async () => {
      deletelike.mockResolvedValue(1);

      const res = await request(app)
        .delete('/api/book/dislike')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 1 });

      expect(res.status).toBe(200);
      expect(res.text).toBe('disliked');
    });

    it('should return 500 for server error', async () => {
      deletelike.mockResolvedValue(0);

      const res = await request(app)
        .delete('/api/book/dislike')
        .set('Authorization', `Bearer ${token}`)
        .send({ bookid: 1 });

      expect(res.status).toBe(500);
      expect(res.body.message).toBe('server error');
    });
  });

  describe('GET /api/book/favorit', () => {
    it('should return favorite books', async () => {
      favorit_books.mockResolvedValue({ data: [{ bookid: 1, title: 'Book 1' }] });

      const res = await request(app)
        .get('/api/book/favorit')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(200);
      expect(res.body).toEqual([{ bookid: 1, title: 'Book 1' }]);
    });

    it('should return 204 for no content', async () => {
      favorit_books.mockResolvedValue(0);

      const res = await request(app)
        .get('/api/book/favorit')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(204);
    });
  });

  describe('GET /api/book/likestatus', () => {
    it('should return like status', async () => {
      likeStatus.mockResolvedValue({ isLiked: true });

      const res = await request(app)
        .get('/api/book/likestatus')
        .set('Authorization', `Bearer ${token}`)
        .query({ bookid: 1 });

      expect(res.status).toBe(200);
      expect(res.body.status).toBe(true);
    });

    it('should return 400 for missing bookid', async () => {
      const res = await request(app)
        .get('/api/book/likestatus')
        .set('Authorization', `Bearer ${token}`);

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter bookid and userid');
    });
  });

  describe('GET /api/book/bookdetail', () => {
    it('should return book details', async () => {
      GetBookByID.mockResolvedValue([
        {
          BookID: 1,
          Title: 'Book 1',
          AuthorName: 'Author 1',
          PublisherName: 'Publisher 1',
          GenreName1: 'Genre 1',
          Description: 'Description',
        },
      ]);

      const res = await request(app)
        .get('/api/book/bookdetail')
        .query({ bookid: 1 });

      expect(res.status).toBe(200);
      expect(res.body.book.Title).toBe('Book 1');
    });

    it('should return 400 for missing bookid', async () => {
      const res = await request(app).get('/api/book/bookdetail');

      expect(res.status).toBe(400);
      expect(res.body.error).toBe('enter bookid param');
    });

    it('should return 404 for book not found', async () => {
      GetBookByID.mockResolvedValue([]);

      const res = await request(app)
        .get('/api/book/bookdetail')
        .query({ bookid: 1 });

      expect(res.status).toBe(404);
      expect(res.body.message).toBe('Book not found');
    });
  });

  describe('GET /api/book/MBTIbooks', () => {
    it('should return MBTI books', async () => {
      MBTIbooks.mockResolvedValue([{ bookid: 1, title: 'Book 1' }]);

      const res = await request(app)
        .get('/api/book/MBTIbooks')
        .set('Authorization', `Bearer ${token}`)
        .query({ searchterm: 'test', pagenum: 1, count: 10 });

      expect(res.status).toBe(200);
      expect(res.body.books).toEqual([{ bookid: 1, title: 'Book 1' }]);
    });

    it('should return 500 for server error', async () => {
      MBTIbooks.mockResolvedValue(-1);

      const res = await request(app)
        .get('/api/book/MBTIbooks')
        .set('Authorization', `Bearer ${token}`)
        .query({ searchterm: 'test', pagenum: 1, count: 10 });

      expect(res.status).toBe(500);
      expect(res.body.error).toBe('server error');
    });
  });
});